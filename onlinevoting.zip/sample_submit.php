<?php
$sub = $_GET['text'];
$list = $_GET['list'];
var_dump($list);